from Crypto.Cipher import AES
import base64

SECRET_KEY = b'1234567890123456'

def encrypt_message(message,key):

    cipher = AES.new(key,AES.MODE_EAX)
    ciphertext,tag = cipher.encrypt_and_digest(message.encode())

    return base64.b64encode(cipher.nonce + ciphertext)

def decrypt_message(ciphertext,key):

    data = base64.b64decode(ciphertext)

    nonce = data[:16]
    encrypted = data[16:]

    cipher = AES.new(key,AES.MODE_EAX,nonce=nonce)

    return cipher.decrypt(encrypted).decode()
