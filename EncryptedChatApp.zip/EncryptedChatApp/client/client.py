import socket
import threading
from crypto_utils import encrypt_message,decrypt_message,SECRET_KEY

HOST="127.0.0.1"
PORT=5000

def receive_messages(client):

    while True:
        try:
            data = client.recv(4096)

            if data.startswith(b"USERS:"):

                users = data.decode().split(":")[1]
                print("\nOnline Users:", users)

            elif data.startswith(b"FROM:"):

                header, encrypted = data.split(b":",2)[1:]

                sender = header.decode()

                msg = decrypt_message(encrypted, SECRET_KEY)

                print(f"\n{sender}: {msg}")

            else:
                pass

        except:
            print("Disconnected from server")
            client.close()
            break

def send_messages(client,username):

    receiver=None

    print("\nCommands:")
    print("/switch username  -> change chat user")
    print("/exit             -> quit")
    print()

    while True:

        msg=input("")

        if msg.startswith("/switch"):

            parts=msg.split()

            if len(parts)==2:
                receiver=parts[1]
                print(f"Now chatting with {receiver}")
            else:
                print("Usage: /switch username")

            continue

        if msg == "matrix":
            print("Wake up, Neo...")
            print("The Matrix has you.")
            print("Follow the white rabbit.")
            continue

        if msg == "hack":
            print("Initializing cyber attack...")
            print("Bypassing firewall...")
            print("Decrypting packets...")
            print("Access granted.")
            continue

        if msg == "coffee":
            print("☕ Coffee detected.")
            print("Developer productivity +200%")
            continue

        if msg == "game":

            import random
            number=random.randint(1,5)
            guess=int(input("Guess number 1-5: "))
            if guess==number:
                 print("You win!")
            else:
                 print("Wrong. Number was",number)
            continue

        if msg=="/exit":
            client.close()
            break

        if receiver is None:
            print("Select a user first: /switch username")
            continue
        

        encrypted=encrypt_message(msg,SECRET_KEY)

        packet=f"MSG:{username}:{receiver}:".encode()+encrypted

        client.send(packet)


def start_client():

    client=socket.socket(socket.AF_INET,socket.SOCK_STREAM)

    client.connect((HOST,PORT))

    username=input("Enter username: ")

    client.send(username.encode())

    print("Connected to secure chat")

    receive_thread=threading.Thread(target=receive_messages,args=(client,))
    receive_thread.start()

    send_messages(client,username)

start_client()
