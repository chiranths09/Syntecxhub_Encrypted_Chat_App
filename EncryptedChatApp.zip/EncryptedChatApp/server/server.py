import socket
import threading
from logger import log_event

HOST="0.0.0.0"
PORT=5000

clients={}

def send_user_list():
    users=",".join(clients.keys())
    message=f"USERS:{users}".encode()
    for c in clients.values():
        try:
            c.send(message)
        except:
            pass

def handle_client(client,addr):

    print(f"[CONNECTED] {addr}")

    try:
        username=client.recv(1024).decode()
    except:
        client.close()
        return

    clients[username]=client

    print(f"{username} joined")
    log_event(f"{username} connected")

    send_user_list()

    while True:
        try:
            data=client.recv(4096)
            if not data:
                break

            decoded=data.decode()
            parts=decoded.split(":",3)

            if parts[0]=="MSG":

                sender=parts[1]
                receiver=parts[2]
                encrypted=parts[3].encode()

                print(f"{sender} -> {receiver}")
                log_event(f"{sender} -> {receiver}")

                if receiver in clients:

                    packet = f"FROM:{sender}:".encode() + encrypted

                    try:
                     clients[receiver].send(packet)
                    except:
                     pass

        except:
            break

    if username in clients:
        del clients[username]

    client.close()

    print(f"[DISCONNECTED] {username}")
    log_event(f"{username} disconnected")

    send_user_list()

def start_server():

    server=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    server.bind((HOST,PORT))
    server.listen()

    print(f"Server running on port {PORT}")

    while True:
        client,addr=server.accept()
        thread=threading.Thread(target=handle_client,args=(client,addr))
        thread.start()

start_server()
