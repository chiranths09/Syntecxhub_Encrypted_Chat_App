import datetime

LOG_FILE = "../logs/chat_log.txt"

def log_event(event):
    time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_FILE,"a") as f:
        f.write(f"[{time}] {event}\n")
